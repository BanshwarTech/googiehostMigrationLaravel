
<?php $__env->startSection('content'); ?>
    <?php
        $pageName = 'freewordpresshosting'; // Define page name for this view
    ?>
    
    <?php echo $__env->make('includes.hero-section', ['data' => $data], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <section class="py-5">
        <div class="container">
            <div class="content-upgrade mb-mid block-single box-lr " style="background-color: #F9F5FF;  color: #FFFFFF;">

                <div class="content-upgrade-text mb-single ">
                    <p class="banner__heading">Host your website with Free Wordpress Hosting
                    </p>
                    <p class="banner__content mb-4">Free Wordpress Website Hosting with no restrictions.With record speed,
                        performance, and 24/7 support, EasyWP gets your WordPress site up fast.</p>
                    <a href="signup" class="btn banner__btn " rel="me"><?php echo e(strtoupper('Signup Now')); ?></a>
                </div>

            </div>
        </div>
    </section>

    
    <section>
        <div class="container pb-5 ">
            <h2 class="text-center sec-heading">Amazing Features of Free WordPress Hosting →</h2>
            

            <div class="row g-4 mt-4">
                
                <?php echo $__env->make('includes.services-section', ['data' => $data], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            </div>
        </div>
    </section>

    
    <div class="container pricing-section py-5">
        <h2 class="sec-heading text-center">Give More Power To Your WordPress Site →</h2>
        <p class="sec-subheading text-center mb-5">You will get the best Free WordPress Hosting Features which will help you
            grow more and GoogieHost also helps you to migrate your Data to any Premium Hosting Provider.</p>
        
        <?php echo $__env->make('includes.hosting-plans', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>


    
    <div class="container ">
        <h2 class="sec-heading text-center">Grow Without Resistance →</h2>
        <p class="sec-subheading text-center mb-5">It's time for you to grow without limits with FREE WordPress Hosting</p>
        <div class="row g-4">
            
            <div class="col-md-6 col-lg-3">
                <div class="flip-card">
                    <div class="flip-card-inner">
                        <div class="flip-card-front d-flex flex-column align-items-center justify-content-center">
                            <img src="<?php echo e(asset('images/Infinite-WordPress-Themes.png')); ?>" class="w-50 mb-3">
                            <h5 class="fw-bold">Infinite WordPress Themes</h5>
                        </div>
                        <div class="flip-card-back d-flex align-items-center justify-content-center p-4">
                            <p class="text-light"> Scroll through the infinite Exciting WordPress Themes which will give
                                your site a More
                                Amazing and optimized look. You can opt for the theme of your choice and attract more
                                audiences. WordPress consists of millions of themes and you can assess them all with FREE
                                WordPress Hosting.</p>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="col-md-6 col-lg-3">
                <div class="flip-card">
                    <div class="flip-card-inner">
                        <div class="flip-card-front d-flex flex-column align-items-center justify-content-center">
                            <img src="<?php echo e(asset('images/Unlimited-Premium-Plugins.png')); ?>" class="w-50 mb-3">
                            <h5 class="fw-bold">Unlimited Premium Plugins</h5>
                        </div>
                        <div class="flip-card-back d-flex align-items-center justify-content-center p-4">
                            <p class="text-light">The site needs plugins for better performance and the output will be quite
                                smooth and
                                flawless. Even with free WordPress Hosting, you will get the best and the Most famous
                                WordPress Plugins. The Plugins will help you reach your optimization goals.</p>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="col-md-6 col-lg-3">
                <div class="flip-card">
                    <div class="flip-card-inner">
                        <div class="flip-card-front d-flex flex-column align-items-center justify-content-center">
                            <img src="<?php echo e(asset('images/Easy-Rank-On-Google.png')); ?>" class="w-50 mb-3">
                            <h5 class="fw-bold">Turn Your Site Into Store</h5>
                        </div>
                        <div class="flip-card-back d-flex align-items-center justify-content-center p-4">
                            <p class="text-light">With the help of this Free Hosting Service, you will get a better rank on
                                search engines like
                                Google, Yahoo, Bing. The Free Domains are also easy to remember and they will also play a
                                vital role in the ranking of your site.</p>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="col-md-6 col-lg-3">
                <div class="flip-card">
                    <div class="flip-card-inner">
                        <div class="flip-card-front d-flex flex-column align-items-center justify-content-center">
                            <img src="<?php echo e(asset('images/Turn-Your-Site-Into-Store.png')); ?>" class="w-50 mb-3">
                            <h5 class="fw-bold">Easy Rank On Google</h5>
                        </div>
                        <div class="flip-card-back d-flex align-items-center justify-content-center p-4">
                            <p class="text-light">It’s time for you to turn your normal site into an online store. The
                                WordPress Themes and
                                WordPress Plugins will help you convert your simple site into an Online Store. All with Free
                                WordPress Hosting.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <section class="py-5">
        <div class="container">
            <div class="content-upgrade mb-mid block-single box-lr " style="background-color: #F9F5FF;  color: #FFFFFF;">

                <div class="content-upgrade-text mb-single ">
                    <p class="banner__heading">WordPress Hosting Made Easy -Free Domain, SSL & Free CDN
                    </p>
                    <p class="banner__content mb-4">Get web Hosting for your Website with cPanel access.Our free WordPress
                        hosting is 20X faster & easy to install secure WordPress Hosting in minutes.</p>
                    <a href="signup" class="btn banner__btn " rel="me"><?php echo e(strtoupper('Signup Now')); ?></a>
                </div>

            </div>
        </div>
    </section>

    
    <?php echo $__env->make('includes.single-features', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <div class="container mt-5 faq mb-5">
        <h2 class="text-center mb-5 fw-bold">Frequently Asked Questions</h2>
        <div class="accordion bg-white" id="accordionExample0">

            
            <?php echo $__env->make('includes.faq-section', ['data' => $data], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\googiehostMigrationLaravel\googiehost\resources\views/freewordpresshosting.blade.php ENDPATH**/ ?>