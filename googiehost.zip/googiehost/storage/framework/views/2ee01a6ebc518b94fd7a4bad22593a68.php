
<?php $__env->startSection('content'); ?>
    <?php
        $pageName = 'about'; // Define page name for this view
    ?>
    <div class="hero-section">
        <div class="container py-5">
            <div class="row text-center">
                <div class="hero-left-section">
                    <?php $__currentLoopData = $data->heroSections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img src="<?php echo e(asset('storage/uploads/hero/' . $hero->image)); ?>" alt="logo" class="mb-5">
                        <?php echo $hero->title; ?>

                        <?php echo $hero->subtitle; ?>

                        <a href="<?php echo e(route('team')); ?>" class="button_white">Meet GoogieHost Team !</a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>
    </div>

    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h1 class="entry-title mb-4 fw-bold">How GoogieHost Started?</h1>
                    <p>In the early 2010s, Rajesh Chauhan wanted to start his online journey and make a name for himself,
                        but the cost of a domain and web hosting skyrocketed, and an ordinary man could not afford it. But,
                        Rajesh Chauhan took the challenge and decided to make web hosting & new domain registration
                        affordable for an average person. In the summer of 2012, Rajesh founded GoogieHost, which offers 1GB
                        NVMe SSD Storage and 100GB Bandwith without any cost.</p>
                    <p class="quote-box">
                        GoogieHost was founded on beliefs.<br>Rajesh Chauhan - Founder
                    </p>
                </div>
                <div class="col-md-6">
                    <h1 class="entry-title mb-4 fw-bold">It's All About Customers</h1>
                    <p>The GooigeHost ran into many problems with the domain issues with search engine giant Google because
                        GoogieHost sounds like Google hosting, but Google decided to let the web hosting company continue.
                        The GoogieHost had a decent amount of paid users on the platform, but the Blogger Rajesh Chauhan
                        made it a free web hosting platform. The company became a non-profit organisation ever since, and
                        they don’t sell advertisements, they don’t sell your information, and they don’t force you to
                        upgrade to premium.</p>
                </div>

            </div>
        </div>
    </section>


    <section>
        <div class="container bg-white p-0">
            <div class="service-card text-center">
                <h2>Free Service List→</h2>
                <p>Allow us to list down the free services GoogieHost is offering right now.</p>
            </div>
            <div class="row p-5 g-3">
                <?php $__currentLoopData = $data->serviceSections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serviceSections): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                        <div class="card feature-card text-center">
                            <div class=" service-icon mx-auto">
                                <img src="<?php echo e(asset('storage/uploads/service/' . $serviceSections->image)); ?>"
                                    alt="Online File Manager" class="service-img">
                                <?php echo $serviceSections->title; ?>

                            </div>
                            <div class="card-body">
                                <?php echo $serviceSections->description; ?>

                                
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



            </div>
        </div>
    </section>

    <section>
        <div class="container end-content-about mt-5">
            <div>
                <h1 class=" text-center mb-4">Fast forward to 2025</h1>
                <p class=" text-center mb-5 text-white">We offer the ultimate free PHP hosting with cPanel for insanely fast
                    file management. Additionally., we combine it with services packed with our free Website builder,
                    Webmail, SSD boosted Attracta SEO Tools, Fast MySQL Databases and Much more unique things.</p>
                <div class="row">
                    <div class="col-md-6">
                        <div class="feature-list1">
                            <h3><i class="fa-solid fa-check me-3"></i> Free SSL certificate.</h3>
                        </div>

                    </div>
                    <div class="col-md-6">
                        <div class="feature-list1">
                            <h3><i class="fa-solid fa-check me-3"></i>Free on-page SEO.</h3>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="feature-list1">
                            <h3> <i class="fa-solid fa-check me-3"></i>10GB SSD Storage space</h3>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="feature-list1">
                            <h3><i class="fa-solid fa-check me-3"></i> 100GB Bandwidth.</h3>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\googiehostMigrationLaravel\googiehost\resources\views/about.blade.php ENDPATH**/ ?>