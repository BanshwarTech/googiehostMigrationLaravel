<?php $__currentLoopData = $data->serviceSections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serviceSections): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-6 col-lg-4">
        <div class="feature-card">
            <div class=" mx-auto">
                <!-- <img src="./assets/images/icons/root-access.svg" alt="1000MB SSD Storage" class="mb-3"> -->
                <img src="<?php echo e(asset('storage/uploads/service/' . $serviceSections->image)); ?>" alt="Extended Security"
                    class="mb-3">
                <?php echo $serviceSections->title; ?>

            </div>
            <div class="card-body">
                <?php echo $serviceSections->description; ?>

                <?php if(!empty($serviceSections->button_link)): ?>
                    <a href="<?php echo e($serviceSections->button_link); ?>" class="mt-3"
                        style="color: #2b0074;font-weight:bold;font-size:16px;"
                        rel="me"><?php echo e(strtoupper($serviceSections->button_text)); ?> <i
                            class="fa-solid fa-angle-right"></i></a>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\xampp\htdocs\googiehostMigrationLaravel\googiehost\resources\views/includes/services-section.blade.php ENDPATH**/ ?>