<?php $__currentLoopData = $data->faqSection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $faqSection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="accordion-item">
        <h2 class="accordion-header" id="heading<?php echo e($faqSection->id); ?>">
            <button class="accordion-button border-bottom-0 pb-0" type="button" data-bs-toggle="collapse"
                data-bs-target="#collapse<?php echo e($faqSection->id); ?>" aria-expanded="<?php echo e($index == 0 ? 'true' : 'false'); ?>"
                aria-controls="collapse<?php echo e($faqSection->id); ?>">
                <?php echo $faqSection->question; ?>

            </button>
        </h2>
        <div id="collapse<?php echo e($faqSection->id); ?>"
            class="accordion-collapse collapse <?php echo e($index == 0 ? 'show' : ''); ?> border-top-0"
            aria-labelledby="heading<?php echo e($faqSection->id); ?>" data-bs-parent="#accordionExample0">
            <div class="accordion-body">
                <?php echo $faqSection->answer; ?>

            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\xampp\htdocs\googiehostMigrationLaravel\googiehost\resources\views/includes/faq-section.blade.php ENDPATH**/ ?>