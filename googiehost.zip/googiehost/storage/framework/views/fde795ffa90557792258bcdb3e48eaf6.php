
<?php $__env->startSection('page_title', 'Index'); ?>
<?php $__env->startSection('content'); ?>

    
    <?php echo $__env->make('includes.hero-section', ['data' => $data], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\googiehostMigrationLaravel\googiehost\resources\views/freewebsitebuilder.blade.php ENDPATH**/ ?>