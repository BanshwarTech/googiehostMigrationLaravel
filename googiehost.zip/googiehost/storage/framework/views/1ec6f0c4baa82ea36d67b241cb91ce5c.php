<?php $__currentLoopData = $data->heroSections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $heroSection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="hero-section">
        <div class="container">
            <div class="row">
                <div class="hero-left-section col-md-6">
                    <?php echo $heroSection->title; ?>

                    <?php if(request()->routeIs('home')): ?>
                        <h2>Secure &amp; Powerful</h2>
                    <?php endif; ?>


                    <?php if($heroSection->subtitle != null): ?>
                        <?php echo $heroSection->subtitle; ?>

                    <?php endif; ?>
                    <?php if($heroSection->listing_point != null): ?>
                        <?php echo $heroSection->listing_point; ?>

                    <?php endif; ?>

                    <a href="signup.php" class="button_orange">Start for Free </a>
                    <div class="rated">
                        <span>
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="20" viewBox="0 0 18 20"
                                fill="none">
                                <path
                                    d="M12.5 7.5L8 12L6.5 10.5M9 1L1 5C1 10.1932 3.78428 17.5098 9 19C14.2157 17.5098 17 10.1932 17 5L9 1Z"
                                    stroke="#F4FFF9" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                                </path>
                            </svg>
                        </span>No Credit Card required
                    </div>
                </div>
                <div class="hero-image-section col-md-6 text-center">
                    <img src="<?php echo e(asset('storage/uploads/hero/' . $heroSection->image)); ?>" alt="GoogiehostHeroImage"
                        class="img-fluid">
                </div>
            </div>
        </div>
        <div class="inner container " style="padding-top: 0 !important;">
            <img loading="lazy" alt="featured on logos" class="img-fluid"
                src="<?php echo e(asset('images/featured-logos.png')); ?>">
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\xampp\htdocs\googiehostMigrationLaravel\googiehost\resources\views/includes/hero-section.blade.php ENDPATH**/ ?>