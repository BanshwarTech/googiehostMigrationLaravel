
<?php $__env->startSection('content'); ?>
    <div class="pagetitle d-flex justify-content-between align-items-center">
        <div>
            <h1>Manage Faq Section</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.index')); ?>">Admin</a></li>
                    <li class="breadcrumb-item active">Faq Section</li>
                </ol>
            </nav>
        </div>
        <div>
            <a href="<?php echo e(route('admin.faq-section')); ?>" class="btn btn-primary">
                <i class="bi bi-skip-backward-circle"></i> Back
            </a>
        </div>
    </div>
    <section class="section">
        <div class="row">


            <div class="col-lg-12">

                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">
                            <?php echo e(isset($data->id) ? 'Update' : 'Create'); ?> Hero Section
                        </h5>

                        <form class="row g-3" method="POST"
                            action="<?php echo e(isset($data->id) ? route('faq.store', $data->id) : route('faq.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($data->id ?? ''); ?>">
                            <div class="mb-3 col-12 col-lg-12 col-md-12">
                                <label for="page_id">Page Name</label>
                                <select class="form-select" id="page_id" name="page_id">
                                    <option value="">Select Page</option>
                                    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($page->id); ?>"
                                            <?php echo e(old('page_id', $data->page_id ?? '') == $page->id ? 'selected' : ''); ?>>
                                            <?php echo e($page->page_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['page_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="message"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>


                            <div class="mb-3 col-12 col-lg-6 col-md-6">
                                <label for="question" class="form-label">Question</label>
                                <textarea class="tinymce-editor" id="question" name="question"><?php echo e(old('question', $data->question ?? '')); ?></textarea>
                                <?php $__errorArgs = ['question'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="message"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3 col-12 col-lg-6 col-md-6">
                                <label for="answer" class="form-label">Answer</label>
                                <textarea class="tinymce-editor" id="answer" name="answer"><?php echo e(old('hero_title', $data->answer ?? '')); ?></textarea>
                                <?php $__errorArgs = ['answer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="message"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div>
                                <button type="submit"
                                    class="btn btn-primary col-12 col-lg-12 col-md-12"><?php echo e(isset($data->id) ? 'Update' : 'Create'); ?></button>
                            </div>

                        </form>


                    </div>
                </div>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.includes.layouts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\googiehostMigrationLaravel\googiehost\resources\views/admin/manage-faq-section.blade.php ENDPATH**/ ?>