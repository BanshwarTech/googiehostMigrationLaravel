
<?php $__env->startSection('content'); ?>
    <div class="pagetitle d-flex justify-content-between align-items-center">
        <div>
            <h1>Manage Hero Section</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.index')); ?>">Admin</a></li>
                    <li class="breadcrumb-item active">Hero Section</li>
                </ol>
            </nav>
        </div>
        <div>
            <a href="<?php echo e(route('admin.hero-section')); ?>" class="btn btn-primary">
                <i class="bi bi-skip-backward-circle"></i> Back
            </a>
        </div>
    </div>
    <section class="section">
        <div class="row">


            <div class="col-lg-12">

                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">
                            <?php echo e(isset($data->id) ? 'Update' : 'Create'); ?> Hero Section
                        </h5>

                        <form class="row g-3" enctype="multipart/form-data" method="POST"
                            action="<?php echo e(isset($data->id) ? route('hero.store', $data->id) : route('hero.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($data->id ?? ''); ?>">
                            <div class="mb-3 col-12 col-lg-6 col-md-6">
                                <label for="page_id">Page Name</label>
                                <select class="form-select" id="page_id" name="page_id">
                                    <option value="">Select Page</option>
                                    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($page->id); ?>"
                                            <?php echo e(old('page_id', $data->page_id ?? '') == $page->id ? 'selected' : ''); ?>>
                                            <?php echo e($page->page_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['page_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="message"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mb-3 col-12 col-lg-6 col-md-6">
                                <label for="title" class="form-label">Hero Title</label>
                                <textarea class="tinymce-editor" id="title" name="title"> <?php echo e(old('title', $data->title ?? '<h1 class="entry-title"></h1>')); ?></textarea>
                                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="message"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3 col-12 col-lg-6 col-md-6">
                                <label for="subtitle" class="form-label">Hero Subtitle</label>
                                <textarea class="tinymce-editor" id="subtitle" name="subtitle"><?php echo e(old('subtitle', $data->subtitle ?? '<p style="font-size:16px;"></p>')); ?></textarea>
                                <?php $__errorArgs = ['subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="message"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3 col-12 col-lg-6 col-md-6">
                                <label for="listing_point" class="form-label">Listing Point</label>
                                <textarea class="tinymce-editor" id="listing_point" name="listing_point"><?php echo e(old(
                                    'hero_title',
                                    $data->listing_point ?? '<ul id="hero_list_check" class="list light-list list-check"><li></li> </ul>',
                                )); ?></textarea>
                                <?php $__errorArgs = ['listing_point'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="message"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3 col-12 col-lg-6 col-md-6">
                                <label for="image" class="form-label">Hero Image</label>
                                <input type="file" class="form-control" id="image" name="image">
                                <?php if(!empty($data->image)): ?>
                                    <img src="<?php echo e(asset('storage/uploads/hero/' . $data->image)); ?>" alt=""
                                        class="img-fluid" width="75">
                                <?php endif; ?>
                                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="message"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div>
                                <button type="submit"
                                    class="btn btn-primary col-12 col-lg-12 col-md-12"><?php echo e(isset($data->id) ? 'Update' : 'Create'); ?></button>
                            </div>

                        </form>


                    </div>
                </div>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.includes.layouts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\googiehostMigrationLaravel\googiehost\resources\views/admin/manage-hero-section.blade.php ENDPATH**/ ?>