
<?php $__env->startSection('content'); ?>
    <div class="pagetitle d-flex justify-content-between align-items-center">
        <div>
            <h1>Hero Section</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.index')); ?>">Admin</a></li>
                    <li class="breadcrumb-item active">Hero</li>
                </ol>
            </nav>
        </div>
        <div>
            <a href="<?php echo e(route('manage.hero-section')); ?>" class="btn btn-primary">
                <i class="bi bi-plus-circle"></i> Manage Hero Section
            </a>
        </div>
    </div>

    <section class="section">
        <div class="row">
            <div class="col-lg-12">

                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Hero Section</h5>


                        <!-- Table with stripped rows -->
                        <table class="table datatable">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>
                                        Page Name
                                    </th>
                                    <th>Title</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $hero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($index + 1); ?></td>
                                        <td><?php echo e($hero->page->page_name); ?></td>
                                        <td><?php echo e($hero->title); ?></td>
                                        <td> <a href="<?php echo e(route('manage.hero-section', $hero->id)); ?>"
                                                class="btn btn-primary"><i class="bx bxs-edit"></i> Edit</a>
                                            <form action="<?php echo e(route('hero.delete', $hero->id)); ?>" method="POST"
                                                style="display: inline-block;"
                                                onsubmit="return confirm('Are you sure you want to delete this page?');">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger">
                                                    <i class="bx bxs-trash"></i> Delete
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                        <!-- End Table with stripped rows -->

                    </div>
                </div>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.includes.layouts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\googiehostMigrationLaravel\googiehost\resources\views/admin/hero-section.blade.php ENDPATH**/ ?>