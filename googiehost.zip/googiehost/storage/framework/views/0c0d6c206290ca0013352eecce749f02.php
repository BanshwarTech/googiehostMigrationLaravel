
<?php $__env->startSection('content'); ?>
    <?php
        $pageName = 'terms'; // Define page name for this view
    ?>


    <div class="hero-section">
        <div class="container py-5">
            <div class="row text-center">
                <div class="hero-left-section">
                    <h1 class="entry-title mb-5">Meet GoogieHost Team !</h1>
                </div>
            </div>
        </div>
    </div>

    <section>
        <div class="container py-5">
            <div class="policy-sec">
                <?php echo $data->description; ?>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\googiehostMigrationLaravel\googiehost\resources\views/terms.blade.php ENDPATH**/ ?>