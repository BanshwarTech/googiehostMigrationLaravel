
<?php $__env->startSection('content'); ?>
    <?php
        $pageName = 'team'; // Define page name for this view
    ?>

    <div class="hero-section">
        <div class="container py-5">
            <div class="row text-center">
                <div class="hero-left-section">
                    <h1 class="entry-title mb-5">Meet GoogieHost Team !</h1>
                </div>
            </div>
        </div>
    </div>

    <section class="my-5">
        <div class="container ">
            <div class="row">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="team-block col-lg-4 col-md-6 col-sm-12">
                        <div class="inner-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                            <ul class="social-icons">
                                <li><a href="<?php echo e($team->linkedin_url); ?>"><i class="fab fa-linkedin-in"></i></a>
                                </li>
                                <li><a href="<?php echo e($team->twitter_url); ?>"><i class="fab fa-twitter"></i></a></li>
                            </ul>
                            <div class="image">
                                <a href="#">
                                    <img src="<?php echo e(asset('storage/our-team/' . $team->profile_image)); ?>"
                                        alt="<?php echo e($team->linkedin_url); ?> Googiehost"></a>
                            </div>
                            <div class="lower-content">
                                <h3><a href="#"><?php echo e($team->name); ?></a></h3>
                                <div class="designation"><?php echo e($team->role); ?></div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\googiehostMigrationLaravel\googiehost\resources\views/team.blade.php ENDPATH**/ ?>