
<?php $__env->startSection('page_title', 'Index'); ?>
<?php $__env->startSection('content'); ?>

    
    <style>
        .hero-section {
            background: linear-gradient(90deg, #11253c 0%, #33215d 69%) !important;
            background-image: url(https://res.cloudinary.com/youstable/image/upload/v1658402026/GOOGIEHOST012-01_rnv8jy.jpg) !important;
            background-repeat: no-repeat !important;
            background-size: cover !important;
            background-position: center !important;
            padding: 80px 0px 60px 0px;
            height: 1600px;
        }
    </style>
    <!-- hero section -->
    <?php $__currentLoopData = $data->heroSections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $heroSection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="hero-section h-100">
            <div class="container">
                <div class="row">
                    <div class="hero-left-section col-md-12">
                        <?php echo $heroSection->title; ?>

                        <?php echo $heroSection->subtitle; ?>

                        <form class="d-flex" role="search">
                            <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                            <button class="btn btn-outline-success" type="submit">Search</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\googiehostMigrationLaravel\googiehost\resources\views/freedomains.blade.php ENDPATH**/ ?>