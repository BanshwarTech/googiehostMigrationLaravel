
<?php $__env->startSection('page_title', 'Cheap Vps Hosting'); ?>
<?php $__env->startSection('content'); ?>
    <?php
        $pageName = 'cheap-vps-hosting';
    ?>
    
    <?php echo $__env->make('includes.hero-section', ['data' => $data], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <div class="container mt-5">
        <h2 class="text-center mb-5 sec-heading">Top Best Paid/Free VPS Hosting Providers</h2>
        <?php $__currentLoopData = $data->vpsHosting; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paidVps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row offer-container mx-auto mb-5 sale-row">
                <div class="offer-logo col-12 col-lg-3 mx-auto my-auto align-item-center">
                    <img src="<?php echo e(asset('storage/paidPlans/vpsHosting/logo_image/' . $paidVps->logo_image)); ?>"
                        alt="Kamatera Logo" class="img-fluid w-75">
                    <a href="<?php echo e($paidVps->button_link); ?>">
                        <img src="<?php echo e(asset('storage/paidPlans/vpsHosting/offer_image/' . $paidVps->offer_image)); ?>"
                            alt="Kamatera" width="250">
                    </a>
                </div>
                <div class="offer-content col-12 col-lg-6 d-flex justify-content-center align-items-center">
                    <div>
                        <span class="badge badge-success small">✔ Last Verified Yesterday</span>
                        <div>
                            <h5 class="mb-0 "><?php echo e($paidVps->title); ?></h5>
                            <p class="mb-0"><?php echo e($paidVps->description); ?></p>
                        </div>
                    </div>
                </div>
                <div class="offer-button col-12 col-lg-3 mx-auto my-auto">
                    <span class="badge badge-warning rounded-0">🏆 100% SUCCESS RATE</span>
                    <a href="<?php echo e($paidVps->button_link); ?>" class="btn btn-custom w-100 mt-2"
                        onmouseover="swapText(this, '<?php echo e($paidVps->coupon_code); ?>')"
                        onmouseout="swapText(this, '<?php echo e($paidVps->button_text); ?>')">
                        <?php echo e($paidVps->button_text); ?>

                    </a>

                    <script>
                        function swapText(element, text) {
                            element.innerText = text;
                        }
                    </script>

                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



    </div>
    
    <div class="container">
        <div class="container-box p-4">
            <h2 class="text-center fw-bold">Free VPS Hosting Forever - Activate 30 Days Trial Now</h2>
            <div class="row align-items-center mt-4">
                <div class="col-md-6">
                    <div class="highlight-box shadow">
                        <p>Looking for free VPS hosting? This is the best time to grab ultra-powerful VPS servers for free!!
                            All thanks to <a href="#" class="text-primary fw-bold">Kamatera’s</a> free VPS trial in
                            which you can avail of their robust VPS servers free for 30 days. No additional charges will be
                            applied!!</p>
                        <p>So what are you waiting for? Grab their free VPS hosting trial and enjoy the optimum performance
                            for your website with powerful features such as a cloud load balancer, powerful cloud firewall,
                            free SSL certificate, and much more!!</p>
                        <p>Get free SSL certificates with VPS hosting that offers extra data security from hackers.
                            Kickstart your website with the best VPS Hosting provider.</p>
                    </div>
                </div>
                <div class="col-md-6 text-center">
                    <img src="<?php echo e(asset('images/no-credit-card.svg')); ?>" alt="VPS Hosting" class="img-fluid">
                </div>
            </div>
            <div class="text-center mt-4">
                <a href="https://googiehost.com/blog/go/kamatera-free-vps/" class="cta-button col-12 col-lg-6">START FOR
                    FREE <i class="fa-solid fa-angles-right" aria-hidden="true"></i></a>
            </div>
        </div>
    </div>

    
    <section>
        <div class="container pb-5 ">
            <h2 class="text-center sec-heading">Premium VPS Features Come With Every Plans</h2>

            <div class="row g-4 mt-4">
                
                <?php echo $__env->make('includes.services-section', ['data' => $data], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            </div>
        </div>

    </section>

    
    <section class="py-3">
        <div class="container">
            <div class="inner text-center block-double-tb">
                <h2 class="large-title mb-4">Best Paid/Free VPS Hosting Plans List For 2025</h2>

            </div>


            <?php $__currentLoopData = $data->vpsHostingOffer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $vpsHostingOffer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="custom-review-card">
                    <div class="d-flex justify-content-between align-items-center card-heading-sec">
                        <h5 class="fw-bold"><?php echo e($index + 1); ?>. <?php echo e($vpsHostingOffer->title); ?></h5>
                        <span class="fw-bold">$<?php echo e($vpsHostingOffer->price); ?>/mo</span>
                    </div>
                    <div class="p-4">
                        <div class="row mt-3">
                            <div class="col-md-6">
                                <a href="<?php echo e($vpsHostingOffer->button_link); ?>">
                                    <img src="<?php echo e(asset('storage/offers/vps/' . $vpsHostingOffer->image)); ?>" alt="Offer"
                                        class="img-fluid rounded"></a>
                            </div>
                            <div class="col-lg-3 col-md-6">
                                <div class="d-flex justify-content-between align-items-center">

                                    <a href="<?php echo e($vpsHostingOffer->button_link); ?>" class="best-deal-btn hide-btn1">Claim
                                        deal <i class="fa-solid fa-arrow-right" aria-hidden="true"></i></a>
                                </div>

                                <div class=" stats-box">
                                    <div class="d-flex justify-content-between"><span>Performance</span>
                                        <strong><?php echo e($vpsHostingOffer->performance); ?>/5</strong>
                                    </div>
                                    <div class="d-flex justify-content-between mt-2"><span>Speed
                                        </span><strong><?php echo e($vpsHostingOffer->speed); ?>/5</strong>
                                    </div>
                                    <div class="d-flex justify-content-between mt-2"><span>Support
                                        </span><strong><?php echo e($vpsHostingOffer->support); ?>/5</strong>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3">
                                <a href="https://googiehost.com/blog/go/youstable-dedicated/"
                                    class="best-deal-btn hide-btn">Claim deal <i class="fa-solid fa-arrow-right"
                                        aria-hidden="true"></i></a>
                            </div>
                        </div>

                        <div class="mt-3">

                            <?php echo $vpsHostingOffer->description; ?>

                        </div>

                        <div class="row text-center mt-3 p-2">
                            <div class="col-md-4 review-feature">
                                <span class="">Response Time</span><br>
                                <strong><?php echo e($vpsHostingOffer->response_time); ?> ms to load</strong>
                            </div>
                            <div class="col-md-4 review-feature">
                                <span class="">Server Uptime</span><br>
                                <strong><?php echo e($vpsHostingOffer->server_uptime); ?>%</strong>
                            </div>
                            <div class="col-md-4 review-feature">
                                <span class="">Live Status</span><br>
                                <strong class="online"><?php echo e($vpsHostingOffer->live_status); ?></strong>
                            </div>
                        </div>

                        <div class="mt-3">
                            <div class="accordion" id="accordionExample">
                                <div class="accordion-item key-feature-sec">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button key-feature" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#collapseFeature1"
                                            aria-expanded="true" aria-controls="collapseFeature1">
                                            <?php echo e($vpsHostingOffer->list_heading); ?>:
                                        </button>
                                    </h2>
                                    <div id="collapseFeature1" class="accordion-collapse collapse show"
                                        data-bs-parent="#accordionExample" style="">
                                        <div class="accordion-body">

                                            <?php
                                                $listPoints = '';
                                                if (!empty($vpsHostingOffer->list_point)) {
                                                    // Remove outer <ul> and keep <li> items only
                                                    $listPoints = strip_tags($vpsHostingOffer->list_point, '<li>');
                                                }
                                            ?>

                                            <div class="hosting-key-features">
                                                <?php $__currentLoopData = explode('</li>', $listPoints); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(!empty(trim(strip_tags($point)))): ?>
                                                        <div class="d-flex  align-item-center">
                                                            <i class="fa-solid fa-check feature-check-symbol"
                                                                aria-hidden="true"></i>
                                                            <?php echo $point; ?></li>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>


                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



        </div>
    </section>

    
    <div class="container faq mb-5">
        <h2 class="text-center mb-5 fw-bold">Frequently Asked Questions</h2>
        <div class="accordion bg-white" id="accordionExample0">

            
            <?php echo $__env->make('includes.faq-section', ['data' => $data], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


        </div>
    </div>

    
    <?php echo $__env->make('includes.single-features', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\googiehostMigrationLaravel\googiehost\resources\views/cheap-vps-hosting.blade.php ENDPATH**/ ?>