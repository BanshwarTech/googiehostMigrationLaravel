<Section>
    <div class="container">
        <h4 class="cta__subheading">ACHIEVEMENTS</h4>
        <h2 class="cta_heading text-center">View our Achievements</h2>
        <p class="sec-subheading text-center w-md-75 m-auto mb-5">You will get the best Free WordPress Hosting Features
            which
            will help you grow more and GoogieHost also helps you to migrate your Data to any Premium Hosting Provider.
        </p>
        <div class="achie-content-section text-center">
            <div class="feature1 d-flex">
                <div class="text-start text-white achievements__text">
                    <h3>14 Years</h3>
                    <small>Experience in Years</small>
                </div>
            </div>
            <div class="feature2 d-flex">
                <div class="text-start text-white achievements__text">
                    <h3>99.9%</h3>
                    <small>Uptime Guarantee</small>
                </div>
            </div>
            <div class="feature3 d-flex">
                <div class="text-start text-white achievements__text">
                    <h3>4,32,023</h3>
                    <small>Happy Users</small>
                </div>
            </div>
            <div class="feature4 d-flex">
                <div class="text-start text-white achievements__text">
                    <h3>24/7</h3>
                    <small>Round the Clock Support</small>
                </div>
            </div>


        </div>

    </div>
</Section>
