@extends('includes.layout')
@section('page_title', 'Index')
@section('content')

    {{-- hero section --}}
    <style>
        .hero-section {
            background: linear-gradient(90deg, #11253c 0%, #33215d 69%) !important;
            background-image: url(https://res.cloudinary.com/youstable/image/upload/v1658402026/GOOGIEHOST012-01_rnv8jy.jpg) !important;
            background-repeat: no-repeat !important;
            background-size: cover !important;
            background-position: center !important;
            padding: 80px 0px 60px 0px;
            height: 1600px;
        }
    </style>
    <!-- hero section -->
    @foreach ($data->heroSections as $heroSection)
        <div class="hero-section h-100">
            <div class="container">
                <div class="row">
                    <div class="hero-left-section col-md-12">
                        {!! $heroSection->title !!}
                        {!! $heroSection->subtitle !!}
                        <form class="d-flex" role="search">
                            <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                            <button class="btn btn-outline-success" type="submit">Search</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    @endforeach
@endsection
